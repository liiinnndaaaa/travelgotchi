package com.example.travelgotchi

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val argparam3 = "param1"
private const val argparam4 = "param2"

