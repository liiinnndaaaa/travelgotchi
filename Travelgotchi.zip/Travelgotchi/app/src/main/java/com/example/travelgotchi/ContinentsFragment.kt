package com.example.travelgotchi

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val argparam1 = "param1"
private const val argparam2 = "param2"

